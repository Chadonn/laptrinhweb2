<?php
$a = 10;
$b = 20;

$x= -$b / $a;

print 'Nghiem cua phuong trinh bac nhat la: ' . $x;