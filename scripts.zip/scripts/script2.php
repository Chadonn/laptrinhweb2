<?php
$arr = array (1, 5, 10, 2, 9, 45, 3, 7);

$chieu_dai_mang = count($arr);

for ($i = 0; $i < $chieu_dai_mang; $i++) {
    print $arr[$i] . " ";
}

