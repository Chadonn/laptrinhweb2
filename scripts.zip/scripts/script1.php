<?php
$x = 10;
$y = 20;
$z = 0;

$z = $x + $y;

print $z;